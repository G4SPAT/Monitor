<?php

require_once ('Database.php');

class CsvRepository {
  protected $_dbConnection, $_dbInstance;

  public function __construct() {
    $this->_dbInstance = Database::getInstance();
    $this->_dbConnection = $this->_dbInstance->getdbConnection();
  }

  public function make_dir($param)
  {
    $directory = $_SERVER['DOCUMENT_ROOT'].'/'.$param.'/';
      if (!is_dir($directory)) {
        if(!mkdir($directory,0777, true)){
          die("failed to create folder");
        }
      }
      return $directory;
  }

  public function generate_csv($from, $to)//($day_from, $day_to, $time_from , $time_to)
  {

   try {
          $query = $this->_dbConnection->prepare
            ("SELECT AirTempD_Value as value ,
              date_format(Date_time,'%d-%m-%Y') as day,
              date_format(Date_time,'%H:%i:%s') as time
              FROM AirTempDay WHERE
              Date_time BETWEEN '$from' AND '$to'");

            $query->bindParam(":from", $from, PDO::PARAM_STR);
            $query->bindParam(":to", $to, PDO::PARAM_STR);
            $query->execute();
            if (!$query->rowCount() > 0){
              echo "Sorry choose another date";
            }else{


                $file_location = $this->make_dir("temp");
                $file_name = "temperature-".trim($from)."-TO-".trim($to).".csv";
                $file_export = $file_location . $file_name;
                $data = fopen($file_export, 'w');
                $csv_fields = array();
                $csv_fields[] = 'value';
                $csv_fields[] = 'day';
                $csv_fields[] = 'time';
                fputcsv($data, $csv_fields);
                  while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
                    fputcsv($data, $row);
                    }
              }
            }
              catch (PDOException $e){
                  echo 'ERROR: ' . $e->getMessage();
              }

        }
    }
