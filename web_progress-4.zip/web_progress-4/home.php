<?php
require_once('home.phtml');
//require_once('Libraries/phpMQTT.php');
//require_once('Models/Dataset.php');
//$airTempValue = 0;

/**
$mqtt = new phpMQTT("146.87.2.99", 1883, 60);
if ($mqtt->connect()) {
   $airTempValue = $mqtt->subscribe('/temp ');
    $mqtt->close();

    }
**/