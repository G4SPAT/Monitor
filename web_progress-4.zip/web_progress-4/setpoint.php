<?php
$pageTitle = "setpoint1";
include_once('Dataset.php');
include_once('phpMQTT.php');
$dd = new Dataset();
$point = "";
$newTemp = $_POST['newTemp2'];
//require_once('Subscribe2.php');

if (isset($_POST['addSetPoint'])) {
   $nextSetpoint = $dd->setPointCounter() + 1;
    $currentSetpointNum = $dd->setPointCounter();
    echo "new set point" . $nextSetpoint;
    $dd->createSetPointTable();

}
if (isset($_POST['submit'])) {
    $newSetPointName = $_POST['newSetPointName'];
    $selectOption = $_POST['setpointMenu'];


}


if(isset($_POST['set1'])) {
    $pageTitle = $_POST['value'];
    $newTemp = $_POST['newTemp2'];
    if ($newTemp > 0 && $newTemp <= 50) {
        $mqtt = new phpMQTT("146.87.2.99", 1883, 60); //Change client name to something unique
        if ($mqtt->connect()) {
            $mqtt->publish("/g4/".$pageTitle, "$newTemp");
            $mqtt->close();
        }
    }else {
        echo "Sorry, please choose a new temp between 0 and 50";
    }


}


if (isset($_POST['setpointMenu'])) {
    $pageTitle = $_POST['setpointMenu'];
}


$mqtt = new phpMQTT("146.87.2.99", 1883, "test");
if (!$mqtt->connect()) { //connect to the server
    echo "not connected";
    exit(1);
} else {

    $topics['/g4/c_'.$_POST['setpointMenu']] = array("qos" => 0, "function" => "procmsg");
    $mqtt->subscribe($topics, 0);
    //print_r("\n");
    $counter = 0;
    while ($mqtt->proc()) {
        if ($counter = 0) {
            //sleep(60);
        } else {
            break;
        }
        $counter = $counter + 1;
    }

    $mqtt->close();


    function procmsg($topics, $msg)
    {
        //echo $msg;

    }

}

$str2 = substr($mqtt->getVal(), 2);
if (empty($str2)) {
    $display1 = 0;
} ELSE {
    $display1 = $str2;
}

$desc = $_POST['setpointMenu'];

require_once('setpoint.phtml');





