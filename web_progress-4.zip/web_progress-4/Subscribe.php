<?php
require('phpMQTT.php');
//session_start();
//echo $_SESSION['previous_page'];
//session_abort();
        $mqtt = new phpMQTT("146.87.2.99", 1883, "test");
        if (!$mqtt->connect()) { //connect to the server
            echo "not connected";
            exit(1);
        }
         //currently subscribed topics
        $topics[''] = array("qos" => 0, "function" => "procmsg");
        $mqtt->subscribe($topics, 0);
        print_r("\n");
        while ($mqtt->proc()) {
            sleep(60);
        }

        $mqtt->close();


    function procmsg($topics, $msg) {
    echo $msg;

    }




