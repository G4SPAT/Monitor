
<?php
require_once('Database.php');
require_once('phpMQTT.php');
require_once ('Data.php');
require_once ('DataHumidity.php');
require_once('ChartData.php');
class Dataset {
    var $newLiveTemp = '', $newLiveHumidity = '', $newLiveRain = '', $newLiveSolar = '',
    $newLiveWindDirection = '', $newLiveWindSpeed = '', $newLivePressure = '', $chartData = [];
    protected $_dbHandle, $_dbInstance;
    public function __construct() {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }
    public function fetchAllData() {
        $sqlQuery = 'SELECT * FROM AirTempMain LIMIT 5';
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement
        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new Data($row);
        }
        return $dataSet;
    }
    public function sendLiveTemp($newSet) {

        $sqlQuery = "INSERT INTO liveTemp (value) VALUES ($newSet)";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

    }


    public function fetchChartValues($time)
    {

        $sqlQuery = "select Setpoint1_value from Setpoint1 where (Date_time REGEXP '[^0-9][$time]' ) LIMIT 1";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement
        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new ChartData($row);
            return $row['Setpoint1_value'];
        }
        return $dataSet;
    }

    public function getLiveTemp() {

        $sqlQuery = "SELECT ID, value FROM liveTemp ORDER BY ID DESC LIMIT 1";
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->execute();
        $dataSet = [];
        while($row = $statement->fetch()){
            $dataSet[] = new DataHumidity($row);
            $this->setNewLiveTemp($row['value']);
        }
        return $dataSet;
    }
    public function sendLiveHumidity($newSet) {

        $sqlQuery = "INSERT INTO liveHumidity (value, date_time) VALUES ($newSet, CURRENT_TIMESTAMP )";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        var_dump($statement->execute()); // execute the PDO statement

    }
    public function getLiveHumidity() {
        echo "running";
        $sqlQuery = "SELECT ID, value FROM liveHumidity ORDER BY ID DESC LIMIT 1";
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->execute();
        $dataSet = [];
        while($row = $statement->fetch()){
            $dataSet[] = new DataHumidity($row);
            $this->setNewLiveHumidity($row['value']);
        }
        return $dataSet;
    }

    public function sendLiveRain($newSet) {
        $sqlQuery = "INSERT INTO liveRain (value, date_time) VALUES ($newSet, CURRENT_TIMESTAMP )";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        var_dump($statement->execute()); // execute the PDO statement
    }
    public function getLiveRain() {
        $sqlQuery = "SELECT ID, value FROM liveRain ORDER BY ID DESC LIMIT 1";
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->execute();
        $dataSet = [];
        while($row = $statement->fetch()){
            $dataSet[] = new DataHumidity($row);
            $this->setNewLiveRain($row['value']);
        }
        return $dataSet;
    }

    public function sendLiveSolar($newSet) {
        $sqlQuery = "INSERT INTO liveSolar (value, date_time) VALUES ($newSet, CURRENT_TIMESTAMP )";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        var_dump($statement->execute()); // execute the PDO statement
    }
    public function getLiveSolar() {
        $sqlQuery = "SELECT ID, value FROM liveSolar ORDER BY ID DESC LIMIT 1";
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->execute();
        $dataSet = [];
        while($row = $statement->fetch()){
            $dataSet[] = new DataHumidity($row);
            $this->setNewLiveSolar($row['value']);
        }
        return $dataSet;
    }

    public function sendLiveWindDirection($newSet) {
        $sqlQuery = "INSERT INTO liveWindDirection (value, date_time) VALUES ($newSet, CURRENT_TIMESTAMP )";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement
    }
    public function getLiveWindDirection() {
        $sqlQuery = "SELECT ID, value FROM liveWindDirection ORDER BY ID DESC LIMIT 1";
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->execute();
        $dataSet = [];
        while($row = $statement->fetch()){
            $dataSet[] = new DataHumidity($row);
            $this->setNewLiveWindDirection($row['value']);
        }
        return $dataSet;
    }

    public function sendLiveWindSpeed($newSet) {

        $sqlQuery = "INSERT INTO liveWindSpeed (value, date_time) VALUES ($newSet, CURRENT_TIMESTAMP )";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

    }
    public function getLiveWindSpeed() {

        $sqlQuery = "SELECT ID, value FROM liveWindSpeed ORDER BY ID DESC LIMIT 1";
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->execute();
        $dataSet = [];
        while($row = $statement->fetch()){
            $dataSet[] = new DataHumidity($row);
            $this->setNewLiveWindSpeed($row['value']);
        }
        return $dataSet;
    }


    public function sendLivePressure($newSet) {

        $sqlQuery = "INSERT INTO livePressure (value, date_time) VALUES ($newSet, CURRENT_TIMESTAMP )";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

    }
    public function getLivePressure() {

        $sqlQuery = "SELECT ID, value FROM livePressure ORDER BY ID DESC LIMIT 1";
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->execute();
        $dataSet = [];
        while($row = $statement->fetch()){
            $dataSet[] = new DataHumidity($row);
            $this->setNewLivePressure($row['value']);
        }
        return $dataSet;
    }

    public function fetchLogs(){
        $sqlQuery = 'SELECT * FROM Logs';
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->execute();
        $dataSet = [];
        while($row = $statement->fetch()){
            $dataSet[] = new Data($row);
        }

        return $dataSet;
    }

    public function pupolateLogs($userId, $temperatureValue, $setPointChanged){

        try {

            $sqlQuery = "INSERT INTO Logs (UserID, TemperatureValue, SetPointChanged)
            VALUES ($userId, $temperatureValue, $setPointChanged)";
            $statement = $this->_dbHandle->prepare($sqlQuery);
            $statement->execute($sqlQuery);
            echo "New record created successfully";
        }
        catch(PDOException $e)
        {
            echo $sqlQuery . "<br>" . $e->getMessage();
        }

        $statement = null;


    }

        public function setNewSetPointValue($point, $newValue){
            $mqtt = new phpMQTT("146.87.2.99", 1883, 60);
            if ($mqtt->connect()) { //connect to the server
                $mqtt->publish("/g4/$point", "$newValue"); //change setPoint to its new value
                $mqtt->close(); // close connection
            }
        }

public function setPointCounter() {
    $sqlQuery = "SELECT COUNT(*) FROM (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE '%Setpoint%') newSetpoint";
    $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
   $statement->execute(); // execute the PDO statement
    $print = '';
    foreach($statement->fetch() as $val) {
        $print = $val;
        if (!empty($print)) {
            //echo $print;
            return $print;
            break;
        } else {
            break;
        }
    }
    return $print;
}

public function createSetPointTable() {
    $newName = $this->setPointCounter()+1;
    echo "dsa".$newName;
    $sqlQuery = "CREATE TABLE Setpoint" . $newName . "(setPointID int(5) AUTO_INCREMENT, setPointValue VARCHAR(10), DateTime DATETIME, PRIMARY KEY (setPointID))";
    $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
    $statement->execute(); // execute the PDO statement
    echo "rannnn";
}

    public function createCSV()
    {
        $sqlQuery = 'SELECT AirTempD_id from AirTempDay';

        try{
            $sqlQuery = $this->_dbHandle->prepare($sqlQuery);
            $sqlQuery->execute();
            $fileLocation = '/Users/Timea/Documents/';
            $fileName = "temp24SetPoint1-" . date('d.m.Y') . '.csv';
            $file_export = $fileLocation . $fileName;

            $data = fopen($file_export, 'w');

            $csv_fields = array();

            $csv_fields[] = 'Temp_id';
            $csv_fields[] = 'value';

            fputcsv($data, $csv_fields);

            while ($row = $sqlQuery->fetch(PDO::FETCH_ASSOC)) {
                fputcsv($data, $row);
            }
        }
        catch (PDOException $e){
            echo 'ERROR: ' . $e->getMessage();
        }
    }


    public function setNewLiveTemp($newLiveTemp2) {
        $this->newLiveTemp = $newLiveTemp2;
    }

    public function getNewLiveTemp() {
        return $this->newLiveTemp;
    }

public function setNewLiveHumidity($newLiveHumidity2) {
    $this->newLiveHumidity = $newLiveHumidity2;
}

public function getNewLiveHumidity() {
        return $this->newLiveHumidity;
    }

    public function setNewLiveRain($newLiveRain2) {
    $this->newLiveRain = $newLiveRain2;
}

    public function getNewLiveRain() {
        return $this->newLiveRain;
    }

    public function setNewLiveSolar($newLiveSolar2) {
        $this->newLiveSolar = $newLiveSolar2;
    }

    public function getNewLiveSolar() {
        return $this->newLiveSolar;
    }

    public function setNewLiveWindDirection($newLiveWindDirection2) {
        $this->newLiveWindDirection = $newLiveWindDirection2;
    }

    public function getNewLiveWindDirection() {
        return $this->newLiveWindDirection;
    }

    public function setNewLiveWindSpeed($newLiveWindSpeed2) {
        $this->newLiveWindSpeed = $newLiveWindSpeed2;
    }

    public function getNewLiveWindSpeed() {
        return $this->newLiveWindSpeed;
    }

    public function setNewLivePressure($newLivePressure2) {
        $this->newLivePressure = $newLivePressure2;
    }

    public function getNewLivePressure() {
        return $this->newLivePressure;
    }













}