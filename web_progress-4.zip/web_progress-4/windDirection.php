<?php

include_once('phpMQTT.php');
include_once('Dataset.php');
$dd = new Dataset();

$mqtt = new phpMQTT("146.87.2.99", 1883, "test");
if (!$mqtt->connect()) { //connect to the server
    echo "not connected";
    exit(1);
} else {

    $topics['/wind_d'] = array("qos" => 0, "function" => "procmsg");
    $mqtt->subscribe($topics, 0);
    //print_r("\n");
    $counter = 0;
    while ($mqtt->proc()) {
        if ($counter = 0) {
            //sleep(60);
        } else {
            break;
        }
        $counter = $counter + 1;
    }

    $mqtt->close();


    function procmsg($topics, $msg)
    {
        //echo $msg;

    }

}

$dd->getLiveWindDirection();
$display1 =  $dd->getNewLiveWindDirection();

require_once('windDirection.phtml');


?>