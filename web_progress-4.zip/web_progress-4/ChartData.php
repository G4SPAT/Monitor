<?php

class ChartData
{
    protected $setpointValue, $setId, $setDateTime;
    public function __construct($dbRow) {
        $this->setId = $dbRow['Setpoint1_id'];
        $this->setpointValue = $dbRow['Setpoint1_value'];
        $this->setDateTime = $dbRow['Date_time'];
    }

    public function getSetpointId(){
        return $this->setId;
    }

    public function getChartDataValue(){
        echo $this->setpointValue;
        return $this->setpointValue;
    }

    public function getSetpointDateTime(){
        return $this->setDateTime;
    }

}