<?php
header('Content-disposion: attachment');

require "CsvRepository.php";
$view = new StdClass;
$repo = new CsvRepository;

date_default_timezone_set('GMT');

if(isset($_POST['from']) && isset($_POST['from']) && !empty(trim($_POST['from'])) && !empty(trim($_POST['to']))){
  $from = $_POST['from'];
  $to   = $_POST['to'];

  $from = DateTime::createFromFormat('d-m-Y H:i:s', $from);
  $from = $from->format('Y-m-d H:i:s');

  $to = DateTime::createFromFormat('d-m-Y H:i:s', $to);
  $to = $to->format('Y-m-d H:i:s');

  $view->repo = $repo->generate_csv($from, $to);

}

require_once 'setpoint.phtml';
