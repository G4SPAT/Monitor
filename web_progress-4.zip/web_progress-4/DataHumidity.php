<?php
class DataHumidity {
    protected $HID, $Hvalue;//, $_lastName, $_courseID, $_international, $_photoName;
    public function __construct($dbRow) {
        $this->HID = $dbRow['ID'];
        $this->Hvalue = $dbRow['value'];
    }
    public function getHID(){
        return $this->HID;
    }
    public function getHVal(){
        return $this->Hvalue;
    }
}