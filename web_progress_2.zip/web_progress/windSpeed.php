<?php
require_once('windSpeed.phtml');
?>