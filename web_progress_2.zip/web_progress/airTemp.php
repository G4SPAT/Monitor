<?php
require_once('airTemp.phtml');
?>