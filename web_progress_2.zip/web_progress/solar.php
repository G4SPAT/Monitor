<?php
require_once('solar.phtml');
?>