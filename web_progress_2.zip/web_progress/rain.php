<?php
require_once('rain.phtml');
?>