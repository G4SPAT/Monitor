<?php
require_once('humidity.phtml');
?>