<?php
require_once('Views/humidity.phtml');
?>