<?php
require_once('Views/home.phtml');