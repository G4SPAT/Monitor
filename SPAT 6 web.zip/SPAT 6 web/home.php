<?php
require_once('home.phtml');