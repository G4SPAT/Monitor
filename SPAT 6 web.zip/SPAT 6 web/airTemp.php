<?php
require_once('Views/airTemp.phtml');
?>