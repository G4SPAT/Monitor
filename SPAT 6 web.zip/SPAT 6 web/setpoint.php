<?php
require_once('Views/setpoint.phtml');
?>