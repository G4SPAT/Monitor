<?php
require_once('Views/windSpeed.phtml');
?>