<?php
require_once('Views/rain.phtml');
?>