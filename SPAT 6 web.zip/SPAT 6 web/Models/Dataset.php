
<?php
require_once('Database.php');
require_once ('Data.php');
class Dataset {
    protected $_dbHandle, $_dbInstance;
    public function __construct() {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }
    public function fetchAllData() {
        $sqlQuery = 'SELECT * FROM TempMain LIMIT 5';
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement
        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new Data($row);
        }
        return $dataSet;
    }




    public function createCSV()
    {
        $sqlQuery = 'SELECT Temp_id,value from Temp24';

        try{
            $sqlQuery = $this->_dbHandle->prepare($sqlQuery);
            $sqlQuery->execute();
            $fileLocation = '/Users/Timea/Documents/';
            $fileName = "temp24SetPoint1-" . date('d.m.Y') . '.csv';
            $file_export = $fileLocation . $fileName;

            $data = fopen($file_export, 'w');

            $csv_fields = array();

            $csv_fields[] = 'Temp_id';
            $csv_fields[] = 'value';

            fputcsv($data, $csv_fields);

            while ($row = $sqlQuery->fetch(PDO::FETCH_ASSOC)) {
                fputcsv($data, $row);
            }
        }
        catch (PDOException $e){
            echo 'ERROR: ' . $e->getMessage();
        }
    }



















}