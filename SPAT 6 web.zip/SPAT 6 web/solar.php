<?php
require_once('Views/solar.phtml');
?>